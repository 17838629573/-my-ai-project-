# P14 实战：金智 authserver 架构深挖（ncwu 案例）

> 输入：v2.6 实网探测报告（5 高校主站 0 命中 + P14 命中金智 authserver）
> 本文做什么：P14 认出架构之后的**下一步**——查该架构的已知问题族，给出可验证清单
> 合规：本文只做情报分析与验证设计，不发任何请求

---

## 一、先纠正报告里的一个判断错误

> 报告原文：`/serviceValidate?service=x` → "200 但为**服务出口，无信息泄露**"

**这个判定不成立。** 厦门大学官方对接文档写得很清楚：

```
服务端去 https://ids.xmu.edu.cn/authserver/serviceValidate?ticket=%s&service=回调地址
获取学工号，学工号在 XML 的 user 字段内
返回值：
  cas:user            学工号
  cas:cn              姓名
  cas:eduPersonStaffID 教师标识
  cas:eduPersonOrgDN   所在单位
```

**`serviceValidate` 恰恰是 CAS 里返回用户身份信息的那个端点**——它返回学工号、姓名、单位。

报告之所以看到"无信息泄露"，是因为**没有带有效 ticket**。没凭证当然没数据，这不能证明端点安全。

**这是"验证方法不对"，不是"没有漏洞"。** 正确的验证设计见第三节。

**教训**：`serviceValidate` 这类端点，判据不能是"有没有返回数据"，
而是"**谁能拿到数据 / 用谁的 ticket 能拿到 / service 参数指向哪里**"。

---

## 二、架构确认：金智 authserver = Apereo CAS

两条独立证据：

**证据 1 · 江苏政府采购网的金智对接文档**

```
https://am.wisedu.com/authserver/logout?service=...
listener-class: edu.yale.its.tp.cas.client.SingleSignOutHttpSessionListener
```

`edu.yale.its.tp.cas.client` 是 **Yale CAS 客户端包名**——金智 authserver 基于 Apereo CAS（CAS 由耶鲁发起）。

**证据 2 · 端点命名一致**

`/authserver/login`、`/authserver/logout`、`/authserver/serviceValidate`
——这是金智对 CAS 标准端点的统一前缀封装。厦大（`ids.xmu.edu.cn/authserver/`）、
ncwu（`authserver.ncwu.edu.cn/authserver/`）命名完全一致。

**架构确认的意义**：CAS 是被研究得最透的 SSO 实现之一，
**它的已知问题族是公开的**。P14 的杠杆就在这里——认出架构，直接拿到问题清单。

---

## 三、CAS 已知问题族 → ncwu 可验证清单

### 问题族 1 · service 参数未白名单校验 ★★★★★

**根因**：CAS 登录成功后带 `ticket` 重定向到 `service` 参数指定的地址。
若 `service` 未做白名单，**攻击者可把 service 改成自己的服务器，直接窃取 victim 的 ticket**。

这是 CAS 部署层面最高频的问题，因为是**配置项**（`service registry`），不是代码 bug——
很多学校部署时用了通配 `*` 或 `https://*`。

**验证设计**（需 A/B 凭证，低频 1-2 请求）：

```
观察点 1：/authserver/login?service=https://attacker-controlled.example
         → 是否接受任意 service？是否被改写为白名单地址？
观察点 2：登录页返回的 HTML 里，service 值是否被原样写入 form hidden 字段
         → 原样写入 = 未校验
观察点 3：跳转时 ticket 是否被拼到 attacker 域名上
```

**判据**：`service` 接受非本校域名且登录成功后 ticket 被送至该域名 = 命中。
**注意**：只需观察重定向目标，**不需要真的让受害者登录**。

### 问题族 2 · SAML/XML 签名包装（XSW）★★★★★

**这条跟我们工作流已有的根因族完全重合**——
`invariant_conflict` / `sig_separation`：签名校验的对象 ≠ 实际取值的对象。

Somorovsky 论文《On Breaking SAML》的经典形态：

```java
NodeList nodes = doc.getElementsByTagName("saml:Assertion");
element = (Element) nodes.item(0);   // ← 取第一个
```

攻击者把恶意 assertion **放在合法签名 assertion 之前**，
校验方验的是后面那个（签名有效），取的是前面那个（攻击者构造）。

已知实例：SSO 统一认证 SAML 绕过，关联 5 个供应商 6 个 CVE。

**验证设计**：需确认 ncwu 的 authserver 是否开启 SAML/IdP 模式。
若 `/authserver/` 下存在 `samlValidate`、`/idp/` 等端点才适用。

### 问题族 3 · CAS 4.x 反序列化 ★★★★

`execution` 参数 → `flowExecutionKey` → Spring WebFlow 反序列化。
历史上有多个利用链。老版本 CAS 存量很大。

**验证设计**：先确认版本。版本串是唯一坐标：
- `/authserver/` 页面底部版权/版本号
- 错误页栈信息
- `login` 页面的 JS/CSS 路径版本戳

**不要盲打 payload**——先取版本，版本在影响范围内再做。

### 问题族 4 · 高校漏洞类型前四位（EDUSRC 公开数据）★★★★

教育漏洞报告平台统计，**高校漏洞占比最高的四类**：

```
弱口令 · 敏感信息泄露 · SQL注入 · 逻辑缺陷
```

对应到 authserver 的可验证点：

| 类型 | 验证点 | 是否需凭证 |
|---|---|---|
| 弱口令 | 初始口令规则（身份证后6位/学号）提示是否存在 | 否（看提示文案） |
| 敏感信息泄露 | 登录失败提示是否区分"用户不存在"/"密码错误" | 否 |
| 逻辑缺陷 | 验证码是否刷新、是否可复用、是否非空可过 | 否 |
| SQL注入 | 用户名框 | **否要盲打**——不建议 |

**前三项都是纯观察，不需要凭证，不需要发包构造。**

其中"**登录失败提示区分用户是否存在**"是典型的用户枚举，
高校统一认证里非常普遍——因为要提示"该学号未激活"之类。

### 问题族 5 · 姜开达效应（同族扩展）★★★★

> "某个学校使用的某学生管理系统出现了一个漏洞，
> 这个漏洞往往同时出现在全国其他地区成百上千的学校中"

**这正是 `vendor_recurrence` 维度在教育行业的形态**——
只不过复发的不是"同厂商跨年"，是"**同厂商跨校**"。

**操作**：金智 authserver 的任何一个配置/逻辑问题，在
厦大、河大、华水、其他金智客户校上大概率同样存在。
**在一个校验证成功 → 其他校只需确认指纹，不需重新挖。**

---

## 四、给下一轮 Agent 的最小动作清单

按 P14 低频原则：**只读、单请求、0.2-0.5 req/s、命中即停**

| # | 动作 | 请求数 | 判据 |
|---|---|---|---|
| 1 | 取 authserver 版本串 | 1 | 页面底部/错误页/静态资源版本戳 |
| 2 | 观察登录失败提示是否区分用户存在性 | 2 | 不存在学号 vs 存在学号+错密码，响应是否不同 |
| 3 | 观察 service 参数是否被接受任意域名 | 1 | `?service=https://example.com` 是否被改写 |
| 4 | 观察验证码刷新策略 | 2 | 连续两次请求验证码是否为同一张 |
| 5 | 确认是否存在 samlValidate / idp 端点 | 2 | 存在 → 问题族 2 适用 |
| 6 | crt.sh 补子域（换源：SecurityTrails/FOFA） | — | hbnu 无 CT 记录，需换源 |

**以上 8 个请求，全部只读、不登录、不爆破。**

---

## 五、对工作流的两点修正建议

### 1. P14 架构池要加"教育行业"一类

目前六类是：建站/CMS · 后端框架 · AI/自动化 · 中间件网关 · 运维DevOps · 数据缓存。

**缺教育行业这一整块**——而高校 SRC 是独立赛道：
金智（Wisedu）authserver、强智教务、正方教务、今日校园、Blackboard、知网、超星。

### 2. P14 的判据要加一条：端点语义先查清再判定

报告把 `serviceValidate` 判为"无信息泄露"，是**没查端点语义**就下了结论。

**新增纪律**：P14 认出架构后，先查该架构的标准端点语义
（尤其**返回敏感数据的那个端点**），再决定判据。
不能因为"没带凭证所以没数据"就排除。

---

## 六、诚实边界

1. 以上问题族是 **CAS 的公开已知问题**，不是 ncwu 的已确认漏洞。
   **全部是待验证假设，不是发现。**
2. 问题族 1/2/3 的验证需要 A/B 凭证或至少观察重定向行为，
   沙箱无凭证 → 只能做到"确认架构 + 列出待测清单"。
3. 版本未确认，问题族 3（反序列化）可能完全不适用。
4. 金智对 CAS 做过二次封装，标准 CAS 端点行为可能有差异——
   **不能直接照搬 Apereo CAS 官方行为**。
